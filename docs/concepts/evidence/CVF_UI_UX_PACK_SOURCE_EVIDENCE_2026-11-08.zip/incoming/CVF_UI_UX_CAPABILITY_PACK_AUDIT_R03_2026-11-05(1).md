# CVF UI/UX Capability Pack — Independent Source & Architecture Audit R03

**Ngày:** 2026-11-05 (Asia/Ho_Chi_Minh)  
**Vai trò:** External/Web Research Agent — advisory/recommendation only  
**Phạm vi:** CVF là framework gốc và consumer trực tiếp của UI/UX Capability Pack; LAW là project/use case riêng, **OUT OF SCOPE cho quyết định tích hợp lần này**.  
**Trạng thái:** `R03_ADVISORY_ONLY / NOT_IMPLEMENTED / NO_CVF_ADOPTION / NO_LIVE_AB_TEST`.  
**Nguồn trước:** R01 đánh giá các repo; R02 đánh giá ý tưởng pack đa agent. **R03 thay thế kết luận kiến trúc có điều kiện của R02**, không thay thế mọi bằng chứng nguồn R01/R02.  
**Quyền chốt cuối:** Local Agent đối chiếu source owner và trạng thái private/local CVF, phản biện, quyết định technical disposition theo thẩm quyền CVF; Operator phê duyệt tác động/tiếp nhận khi cần. Web agent không có thẩm quyền này.

## 0. Executive disposition

**Đề xuất ưu tiên:** `CVF-FIRST / EXISTING-OWNER-FIRST / REFERENCE-FIRST / HOST-NATIVE-ENTRY-ONLY-IF_GAP_PROVEN`.

- Xây dựng/đánh giá **UI/UX Capability Pack** như một tập hợp tài nguyên chuyên môn được sàng lọc phục vụ coding agents làm việc dưới CVF; chưa vội đưa nó vào Core hay tự viết registry, dispatcher, admission engine.
- **Critical discovery:** public CVF Provenance **đã có** `cvf-engineering-frontend-ui`, `cvf-engineering-browser-runtime-verification`, `cvf-governance-skill-discovery-invocation`, selection-profile source và hệ sinh thái ASSF package/registry/receipts. Vì vậy đề xuất tạo **ba entry skills CVF mới** ở R02 có nguy cơ trùng lặp đáng kể.
- Đề nghị kiểm chứng thêm đúng **một native host entry/adapter mỏng** để Claude/Codex/Gemini khám phá các reference **đã được CVF cho phép**, **chỉ nếu** owner hiện tại không giải quyết được việc này. Nếu native/ASSF hiện tại đủ thì không tạo entry mới.
- Phân biệt nghiêm ngặt: `CVF ASSF package SKILL.md` trong public repo **không tự động là Agent Skills native** (các file đã đọc là Markdown có trường CVF, không có YAML frontmatter chuẩn). `ACTIVE` + `CERTIFIED` được công bố trong ASSF **không có nghĩa** host tự khám phá/auto-invoke, đã thực thi browser, hoặc có quyền sửa/ghi/deploy.
- LAW là một ứng dụng downstream có thể chọn dùng một tập con trong tương lai, **không làm nguồn chuẩn cho CVF**, không kéo `pack.py` hoặc LAW intake vào kiến trúc CVF.
- Chưa nghiệm thu skill bên ngoài. Chưa chạy script, Windows GUI, model live/A-B hay triển khai qua agents. Không nhận upstream README/benchmark claims là CVF-verified.

**Status đề nghị:** `RESEARCH_SHORTLIST_FOR_LOCAL_RECONCILIATION` — chưa `ACCEPT`, `ACTIVE`, `READY` hoặc `INSTALL` bất kỳ capability mới nào.

## 1. Evidence method, freshness & claim boundary

### 1.1 Thu thập

- Đọc R01/R02 trước đó; kiểm tra lại GitHub tree và content qua GitHub read-only connector; kiểm các source owner được trích trong public CVF Provenance.
- Đối chiếu đặc tả Agent Skills / tài liệu Codex / Gemini CLI từ nguồn chính thức. Xem các mã nguồn upstream được nêu trong R02 ở mức selected-file read; không tuyên bố review toàn bộ file tree.
- **Public CVF observed tree:** `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance` commit `1c7125286cf185f00c7b9248aed506889c448aa9`. Đây là quan sát public GitHub, **không** là private/local CVF source-of-truth hoặc commit pin cuối cùng do Local xác nhận.
- Source R02 upstream pins còn hữu ích làm điểm khởi đầu: `anthropics/skills` `ca45fc496a3436251f191354091d557da31c15b5`; `nextlevelbuilder/ui-ux-pro-max-skill` `ccce51cba388476d4f403091ddb91636d5cd9fed`; `vercel-labs/agent-skills` `1a2c79d4e6c4a2283dc2c614b6538cbe1ed5ca62`; `vercel-labs/web-interface-guidelines` `434b7f91364665f2f733b310ec54809bf8f37937`; `Leonxlnx/taste-skill` `9b4bf937a1f69348126959c15d2f99a73e65699b` (v2.5.0, khác hẳn v2.1.x).
- Không có clone local hoặc thực thi chương trình từ các upstream, không audit toàn bộ 20k+ paths của CVF, không kiểm nghiệm private runtime, không đối chiếu toàn bộ dependency/asset licenses.

### 1.2 Cấp bằng chứng sử dụng

- **E1 SOURCE-CONFIRMED:** literal content/metadata từ file cụ thể, ở commit đã quan sát; ví dụ `Status: ACTIVE`, `SKILL.md` không có YAML frontmatter, CLI source path.
- **E2 INFERENCE:** diễn giải hợp lý về overlap, value, architecture và rủi ro từ những phần đã đọc.
- **E3 UNTESTED:** khả năng hoạt động thực tế trong CVF local, host-native discovery, GUI quality, tính di động, tốc độ/cost/token, hiệu lực bảo mật của script.
- **E4 LOCAL-ONLY:** current private owner, active runtime boundary, final adoption, root-update permission, execution effect, phù hợp với chế độ/phase CVF thực tế. External agent không tự suy ra.

## 2. Findings — direct relevance to CVF

### F03-01 [CRITICAL, E1]: CVF đã có package sở hữu frontend UI

**Source:** `docs/reference/agent_system_skills/packages/cvf-engineering-frontend-ui/{SKILL.md,skill.source.json,README.md}` tại public observed commit.

- `SKILL.md`: `Status: ACTIVE`; task classes `frontend-implementation`, `ui-review`, `visual-verification`; source package `frontend-ui-engineering` từ repo `addyosmani/agent-skills` commit `aba7c4e9695c363e65cb59effe926c7f1d1abe3d`.
- `skill.source.json`: `lifecycleState: ACTIVE`, `uatState: PASSED`, `certificationState: CERTIFIED`, `internalAgentDisposition: IMPLEMENTED`, `externalCliMcpDisposition: IMPLEMENTED`.
- **Caveat do chính source ghi:** chỉ có explicit receipt-backed production package execution qua CVF adapter; **không** tự động kích hoạt, UI deployment, browser automation, commit, public-sync hay hành động production.
- Nội dung package hiện mang tính governance/engineering advisory; **chưa chứng minh** nó thay thế được dữ liệu palette, font, semantic layout, design direction của các nguồn mới.

**Proposal:** local agent phải so sánh nhu cầu UI/UX Pack với **chính owner này** trước khi tạo `cvf-ui-web` hay `cvf-ui-desktop` như package CVF mới. Khả năng là bổ sung resources trong phạm vi owner/frontend trước, thay vì create duplicate.

### F03-02 [CRITICAL, E1]: CVF đã có owner browser-runtime-verification và skill-discovery

**Sources:**
- `docs/reference/agent_system_skills/packages/cvf-engineering-browser-runtime-verification/`
- `docs/reference/agent_system_skills/packages/cvf-governance-skill-discovery-invocation/`

Hai package cùng công bố `ACTIVE`, `UAT PASSED` và contract-backed receipt use. Browser package hướng đến DOM/console/screenshot nhưng `skill.source.json` cũng nói rõ Chrome DevTools MCP trong upstream chỉ là **source fact**, chưa được package này cấp quyền cài/khởi chạy browser/MCP.

Skill-discovery package mô tả **metadata-first discovery**; ví dụ role `dispatcher` chọn Allowed Reads, `worker` chỉ mở đúng package được cho phép, `reviewer` kiểm tra claim; không tự thêm Allowed Reads.

**Proposal:** mục đích của các entry skills `cvf-ui-review` và `cvf-ui-reference-entry` phải được chứng minh là **host-native bridge / content indexing gap**, không được trùng chức năng, shadow những ASSF source owner này hoặc tự động nâng quyền.

### F03-03 [HIGH, E1]: CVF đã có selection profiles/inventory — không cần bắt đầu bằng catalog YAML riêng

**Sources:**
- `docs/reference/agent_system_skills/CVF_SKILL_SELECTION_GUIDANCE_STANDARD.md`
- `docs/reference/agent_system_skills/control_plane/source/skill-selection-profiles.json`
- `docs/reference/agent_system_skills/control_plane/generated/skill-inventory.json`
- `governance/compat/run_skill_control_plane_inventory.py`

CVF chuẩn hóa `skillId`, `specSignals`, `recommendedWhen`, `notRecommendedWhen`, `selectionKeywords`, `outputGoals`, priority và generated read model.

Observed profiles:

| Existing skillId | Recommended | Not recommended | Priority |
|---|---|---|---|
| `cvf-engineering-frontend-ui` | spec về UI/component/layout/interaction/visual polish | backend-only hoặc docs-only | 78 |
| `cvf-engineering-browser-runtime-verification` | browser/DOM/console/screenshot | không có browser surface hoặc chỉ docs tĩnh | 72 |
| `cvf-governance-skill-discovery-invocation` | hỏi cách chọn/khám phá/call skill | skill đã chọn và receipt-backed | 90 |

**Proposal:** dùng catalog Markdown như **view có điều kiện và chỉ mục tài liệu bổ trợ**, không biến nó thành source-of-truth thứ hai về trạng thái `ACTIVE`. Nếu cần machine metadata cho UI/UX Pack, Local định vị source owner CVF thực, rồi derive các view từ đó. Không thêm `catalog.yaml` để lưu bản sao status và approval.

### F03-04 [HIGH, E1]: `ASSF SKILL.md` khác native `Agent Skills SKILL.md`

- Public CVF ASSF package files đã kiểm có `# Title`, `Status`, `skillId`, `Invocation Boundary`, `Evidence And UAT`... nhưng không có YAML frontmatter chuẩn `name`/`description` đầu file.
- Native `SKILL.md` của Claude Code, Codex, Gemini CLI theo chuẩn Agent Skills sử dụng YAML frontmatter; native host scanning/activation là chuyện của host, không phải lifecycle `ASSF` của CVF.
- `ACTIVE` trong `skill.source.json` không chứng minh các thư mục CVF hiện tại sẽ được agent host phát hiện tại `.claude/skills/` hay `.agents/skills/`.

**Proposal:** nếu local test thấy cần host-native bridge, thiết kế một `SKILL.md` **adapter nhỏ, generated/projected** theo CVF-allowed scope, không rename ASSF artifact hoặc duplicate package governance. Native adapter load/khám phá không được biến thành `CVF_APPROVED`.

### F03-05 [HIGH, E1]: CVF đã có formal admission, package contract, truth/receipts

Existing owners:

- `docs/reference/agent_system_skills/CVF_ASSF_PACKAGE_CONTRACT.md`
- `docs/reference/agent_system_skills/CVF_ASSF_ACTIVATION_POLICY_SEMANTICS_STANDARD.md`
- `docs/reference/agent_system_skills/CVF_ASSF_PACKAGE_USE_PROOF_ADAPTER_STANDARD.md`
- `docs/reference/agent_system_skills/CVF_ASSF_PRODUCTION_PACKAGE_RUNTIME_STANDARD.md`
- `docs/reference/agent_system_skills/CVF_SKILL_SOURCE_OF_TRUTH_PACKET_STANDARD.md`
- `docs/reference/CVF_EXTERNAL_PROVIDER_SKILL_SOURCE_OF_TRUTH_STANDARD_2026-06-30.md`
- `docs/reference/CVF_EXTERNAL_CAPABILITY_ADMISSION_CONTRACT.md`

Key invariant: `selected` ≠ `activation-ready` ≠ `body-read` ≠ `used-with-receipt`; source/external-provider output **không** là CVF canonical authority. Provider-runtime skill không thay CVF source-of-truth. Package body load không cấp quyền browser, FS, network, commit/deploy.

**Proposal:** không xây admission table mới và không đưa `verified` sticker vào native skill rồi cho phép tự phát hiện nếu local CVF chưa xác nhận đúng scope/hash. Reuse lifecycle, receipts và các requirement của owner đã hoạt động.

### F03-06 [HIGH, E1]: Existing external research protocol giới hạn đúng vai trò của R03

CVF docs:
- `docs/reference/external_agent_review/CVF_CROSS_WORKSPACE_EVIDENCE_RELAY_METHOD.md`
- `docs/reference/external_agent_review/CVF_CROSS_WORKSPACE_DOMAIN_FUNNEL_ABSORPTION_METHOD.md`

Web agent chỉ thu thập, phân nhóm, đối chiếu cơ chế và ghi cơ sở nguồn. **Local Agent** mua/clone/mirror, khóa source pin local, đối chiếu current private owner, use-case recovery, phát hiện trùng, final technical disposition. Task bên ngoài kết thúc tại boundary research-to-execution. Mọi source trong chương trình nhiều repo cần disposition rõ ràng, không xóa mất bằng chứng vì pattern trùng.

**Proposal:** R03 là advisory source-based research; Local chọn task/capsule phù hợp theo các hợp đồng đang có, không thay bằng quy trình R03 tự nghĩ ra.

### F03-07 [HIGH, E1/E2]: Upstream được dùng đúng thế mạnh, không trộn tất cả thành một skill

| Nguồn | Khả năng chọn lọc (candidate) | Hướng phù hợp | Không mặc định nhận |
|---|---|---|---|
| Anthropic `frontend-design` | Design thinking, content/typography/layout, critique | web frontend và phần nguyên tắc chung cho app | Không cho phép phong cách thẩm mỹ override brief hoặc CVF rules |
| UI UX Pro Max | Local CSV search, design system, palette, semantic color, UX guidance | `reference/utility` cho desktop & web | Không coi stack Py Tkinter/Streamlit/NiceGUI là được hỗ trợ chính thức; `${CLAUDE_PLUGIN_ROOT}` không portable |
| Taste Skill 2.5.0 | Marketing/company/product sites, layout/assets, `consistency.mjs` | chuyên biệt website public | Không làm default dashboard / Python offline; không mặc định chạy network/photos/assets/WebGL scripts |
| Vercel Web Interface Guidelines | snapshot có pin để review UX/a11y | web audit/reference | Không fetch `main` động trong task nội bộ; guideline != toàn bộ chuẩn WCAG |
| Vercel React best practices + composition | React/Next specific rules | chọn theo detected stack | Không dùng cho Python/Tkinter hoặc stack khác |
| Anthropic webapp-testing | testing local web bằng Playwright | web UI / NiceGUI / Streamlit local nếu test phù hợp | Không nhận raw generic `networkidle` assertion; không coi test script trusted khi chưa review |
| Fluent Blue | Design system/component docs/audit ideas cho Python Qt | tham khảo desktop; direct only Qt | Không là dependency mặc định của CustomTkinter/Streamlit/NiceGUI |
| Awesome lists | discovery | research intake | Không tải hàng loạt skill, không coi curation là test |

Tất cả hiện là **candidates** đối với UI/UX Pack mới dù một vài upstream pattern tương tự đã được CVF dùng trong các owner khác. Tách rõ **pattern already owned** và **new application-specific content**.

### F03-08 [HIGH, E2]: LAW phải là optional consumer, không phải kiến trúc nguồn

- LAW tồn tại `packs/`, `pack.json`, `skills/local`, `skills/external`, `tools/pack.py`, `tools/install_skills.py`, nhưng đó là implementation trong LAW.
- UI/UX Pack được thiết kế cho agents **trong CVF**. LAW chỉ có thể xem xét **subset** riêng sau này, dựa trên công việc văn phòng trung tâm thực tế.
- Vì vậy không dùng LAW status `REVIEW/AVAILABLE` hoặc LAW `pack.py confirm` làm canonical CVF admission; không copy LAW package schema sang CVF trừ khi Local chứng minh hợp đồng của CVF chọn dùng.

**Proposal:** R03 tạm gạch LAW khỏi kế hoạch implementation/testing/admission. Chỉ đánh dấu `FUTURE_OPTIONAL_CONSUMER`, không đặt milestone cho LAW.

## 3. Architecture options — độc lập, không khóa đáp án

| Lựa chọn | Nội dung | Lợi ích | Rủi ro / điều kiện | R03 disposition |
|---|---|---|---|---|
| **A: Enhance existing ASSF owner** | Bổ sung các references/skills subset đã chấp nhận trong phạm vi `cvf-engineering-frontend-ui`; dùng browser-verification & discovery owners sẵn có | Tránh owner trùng, không tạo engine mới | Local phải xét phạm vi owner, schema, governance gates và cần bổ sung gì | **Ưu tiên so sánh trước** |
| **B: Standalone UI/UX content pack, CVF-owned** | Tập hợp reference/asset/script đã kiểm, với các binding tới source owners hiện có; không tự điều phối | Dễ update/reuse, tách UI content khỏi core; có thể dùng web + Python | Need host access, packaging, version+source identity, không trùng status | **Ứng viên kiến trúc chính** |
| **C: Tiny host-native entry skill** | Một `SKILL.md` chuẩn Agent Skills quảng bá UI/UX source index và chỉ dẫn đọc nguồn đã accepted | Hữu ích nếu host chưa nhìn thấy CVF source đúng lúc | Trùng skill discovery owner, broken refs, false triggers, phantom permission | **Conditional adapter, không mặc định** |
| **D: 3 new CVF entry skills** | `cvf-ui-desktop/web/review` ở lớp CVF | Trigger task cụ thể | Trùng 3 owners đã có, tăng bảo trì/status, nhiều skill metadata | **Chưa ủng hộ lúc này** |
| **E: Merge all upstream as mega-skill** | Trộn tất cả guidance/script | Triển khai trực tiếp | Xung đột thẩm mỹ, context bloat, script risk, update khó | **Bác bỏ** |

**Đề xuất kết hợp có điều kiện:** khảo sát A + B, thử C nếu chứng minh có gap native host; chưa chọn D/E. Local có thể phản biện độc lập và chọn phương án khác nếu source/runtime chứng minh tốt hơn.

## 4. Draft boundary of the UI/UX Capability Pack (reference-first)

### 4.1 Pack không làm gì?

- Không thay CVF Core, lifecycle, registry, gate, resolver, provider routing, model selection, work-order authority.
- Không cấp quyền cài dependency, gọi Internet, tải ảnh/font, thực thi scripts, sửa file/project ngoài phạm vi task.
- Không tự tải tất cả skill vào context; không auto-pull upstream `main` rồi coi là accepted.
- Không sửa frontend architecture/code nếu user chỉ yêu cầu review; không tự áp một visual theme lên sản phẩm không phù hợp.
- Không biến LAW thành dependency hay test gate bắt buộc.

### 4.2 Giá trị riêng của pack

Pack nên đóng vai trò **UI/UX domain knowledge and task-specific tools** đã được kiểm, với 4 nhóm tối giản:

1. **Design foundations:** hierarchy, layout density, spacing, typography, semantic tokens, dashboard/forms/tables, local Vietnamese content, accessibility.
2. **Application recipes:** business UI vs marketing page; responsive web; Python desktop; data tool, admin dashboard, landing page.
3. **Optional utilities:** CSV search/design-system generator, browser screenshot/UX audit (chỉ khi quyền và test cho phép).
4. **Evidence and source map:** pin upstream component, license, applied subset, tested agents/OS/stack, capability owner/purpose, limitations, benchmark. Dùng CVF registry/receipts làm nguồn trạng thái có thẩm quyền, không nhân đôi.

### 4.3 Dự thảo lưu trữ KHÔNG đồng nghĩa yêu cầu tổ chức CVF

```text
ui-ux-capability-pack/           # independent candidate content bundle
├── README.md                    # purpose, status, scope, no authority
├── REFERENCES.md                # short human/agent-readable topic index
├── references/
│   ├── fundamentals/           # layout, color, typography, usability
│   ├── application-ui/         # data-heavy UI, tables, forms, errors
│   ├── python-offline/         # tkinter, streamlit, nicegui notes if tested
│   └── web-frontend/           # marketing vs product app; stack-specific
├── capabilities/               # accepted selected files/scripts (if any)
├── evidence/                   # source pins, license, A/B and test artifacts
└── host-entry-candidate/       # OPTIONAL, not installed until Local approves
    └── cvf-ui-reference/SKILL.md
```

- Không bắt buộc tạo `CATALOG.yaml`; CVF đã có `skill.source.json` và selection profile JSON. Nếu cần machine index, derive theo owner canonical, tránh nhiều nơi tự duy trì `approved/ACTIVE`.
- Nếu Host-native skill được chọn, để `SKILL.md` thực sự theo chuẩn Agent Skills (YAML frontmatter + Markdown); **không** bê nguyên ASSF `SKILL.md` sang native host.
- Native entry phải được phát hành với **đường dẫn reference còn hoạt động sau khi cài**: self-contained bundled reference hoặc host-accessible absolute project path được kiểm, có fail-safe. Không quảng bá candidate thành active.

### 4.4 Một host-native entry ứng viên, CHƯA CÀI

```markdown
---
name: cvf-ui-reference
# Example description only; refine after A/B trigger tests.
description: Use for UI/UX design or redesign in a CVF-governed coding task only when approved UI references would add value; skip backend-only work and tasks where native guidance is sufficient.
---

# UI/UX reference entry (candidate)

- Confirm the current CVF task scope, actual frontend/desktop stack, user goals, and allowed reads.
- Discover the CVF-approved UI reference index through the integration path explicitly supplied by this CVF workspace. Do not guess a path.
- Read only the relevant approved reference; never treat source candidates or web content as authority.
- If no accessible approved reference, continue using existing native capabilities and report the gap; do not self-install or fetch unreviewed skills.
- Use coding tools and check UI behavior only within the current authorized task.
- Report which versioned references were actually consulted and what was not tested.
```

Đây là một **candidate host adapter**; nó không thay ASSF selection/activation/receipts; Host native `name` nên kiểm tra trùng, version/host limitations, trigger precision và public/private source boundaries trước đăng ký.

## 5. Proposed smallest useful pilot — falsifiable

### Stage 0: Local owner reconciliation (hard prerequisite for admission)

Local Agent xác minh public observed snapshot vs local/current private CVF:

- Có owner `cvf-engineering-frontend-ui`, `cvf-engineering-browser-runtime-verification`, `cvf-governance-skill-discovery-invocation` nào là **active** và phục vụ đường use case này thực tế?
- Có sẵn native host entry/discover path (Claude/Codex/Gemini) khác chưa xuất hiện trong selected public read không?
- CVF đã có reference, design source, UI audit, skill source mirror, admission record hoặc package source nào đủ cho nhu cầu chưa?
- Lựa chọn content pack B có là extension existing owner hay tạo overlay gây conflict với lifecycle/registry? Tách distinct values và duplicate mechanisms.

### Stage 1: Source component screening (not integration)

Chọn **2–3 nguồn** làm pilot, không lấy tất cả: 

- UI UX Pro Max: **read-only local design-search utility + style/UX data subset**.
- Anthropic frontend-design: phần **planning/visual rationale + content principles**.
- Vercel web-interface-guidelines: **pinned review guideline subset**, chỉ cần nếu chưa trùng existing CVF/browser owner.

Taste v2.5 là riêng **marketing site** ở đợt tiếp theo. React best practices chỉ khi có React/Next task thực. Fluent Blue chỉ cho Qt nếu task có Qt.

Review source chain `SKILL.md → references → scripts → deps/network/filesystem`, legal notices per component. Không chạy installer/unknown `--help` ở candidate quarantine (help/import cũng có thể execute). Không đăng candidate trong native auto-discovery.

### Stage 2: Prove content value before building 3 entry skills

**Baseline A** = agent + native tools/skills **và cơ chế CVF hiện hữu**. Không được vô hiệu hóa native hay existing CVF owner để làm A yếu hơn.

**Treatment B** = A + đúng **một** selected reference/utility đã được test và cho phép.

**Treatment C** (conditional) = B + một tiny native entry để test discovery/route; chỉ chạy khi B tốt mà agent thường xuyên không tìm ra nguồn.

**Treatment D** (conditional) = B + browser/visual verification tool bổ sung; chỉ nếu current CVF verification thiếu đường proof tương ứng.

At least two real tasks, preferably three, all non-production fixtures:

| Test ID | Task | Primary outcomes | Tooling focus |
|---|---|---|---|
| P1 | CustomTkinter offline Excel reconciler UI | Functional accuracy, workflow clarity, long Vietnamese labels, loading/error, Windows DPI, offline fonts | reference value independent of web tools |
| P2 | NiceGUI/Streamlit offline-local admin dashboard | navigation/filter/table usability, no secrets/network leak, screen width, accessibility | browser audit if authorized |
| P3 | React/HTML website or frontend app | responsive, keyboard, semantic markup, visual hierarchy, performance | Vercel/Anthropic references vs native |

Record: exact model+effort+host+version, source pins, identical prompt and fixtures, baseline outputs, correctness, user task success, keyboard/navigation, screenshot quality reviewed by human, bug/retry count, tokens, elapsed time and user correction time if measurable. Unmeasured metrics mark UNKNOWN, not zero. Include negative control `backend-only` to test overtrigger.

### Stage 3: CVF native host bridge test — only if needed

| Test | Expected evidence | Failure mode |
|---|---|---|
| H1 Skill discovery Claude/Codex/Gemini (individual versions) | host lists exactly intended entry | not found or name collision |
| H2 Explicit invocation | reads authorized approved index, resolves reference without guessing | broken path/candidate leak |
| H3 Implicit UI task | correct trigger or justified native fallback | under/over trigger |
| H4 Backend-only negative task | no needless UI skill load | false trigger/token burn |
| H5 Same-name and provider-native preference | no shadow/overwrite native without authority | native replaced |
| H6 Windows packaged/copied deployment | paths resolve, no unsafe junction/symlink requirement | inaccessible reference |
| H7 Version swap and revocation | new upstream source remains candidate, old accepted pin unchanged | silent auto-update |
| H8 No external network/secrets | all effects match scope; exception documented | unapproved download/exfil |

## 6. Decisions local agent needs to issue, without preset answer

1. **Owner map:** exact current CVF authoritative owner for UI/UX content, native entry, selection, browser testing, external intake, and use-proof; cite current paths, commits, implementation/tests.
2. **Overlap verdict:** whether selected upstream mechanisms already covered by current CVF packages; distinguish unique content & gaps vs new owner needed.
3. **Packaging verdict:** (A) extend existing ASSF frontend owner, (B) separate content pack linked to existing owner, (C) native bridge for host discovery, (D) another evidence-based alternative. Keep LAW out.
4. **Public/private boundary:** which sources may be mirrored, distributed, exposed to provider native SKILL, and which must remain private.
5. **Skill source admission:** which files actually copied vs linked; license per asset; OS/scripts/network; record immutable pins and safe stop.
6. **A/B policy:** approve tests for exact host/model/stack; establish fair baseline with native + current CVF, human rubric and success metrics.
7. **Final technical disposition:** ACCEPT/ADAPT/REFERENCE_ONLY/DEFER/REJECT per capability in existing CVF taxonomy; no new status vocabulary unless CVF owner says so. Scope and remaining work clearly distinguished.
8. **Authority boundary:** separate research recommendation, local technical selection, work-order permission, install/execute consent, publish/public-sync permission. No inference from file presence.

### Priority challenge questions (for independent peer review)

- If `cvf-engineering-frontend-ui` already ACTIVE, precisely what value would an external UI/UX Pack provide **over the actual native + existing CVF baseline**? Is it design data, higher-quality outputs, test utility, or a different audience?
- Does current CVF ASSF production path expose usable skill instructions to everyday Claude/Codex/Gemini coding work, or is it a narrowly bounded proof path? Can the content-only pack work without a new router?
- Do we need any new entry skills, or can the current CVF selection profile / `AGENTS.md` point agent at approved references sufficiently? If an entry is needed, why not exactly one?
- How will packaged references remain accessible in copied/symlinked or isolated host execution? What is smallest way to verify that?
- Can guidelines from marketing sites contaminate data-heavy operational UX? How does task-typed selection avoid this without turning into rigid rule hierarchy?
- Can we prove improved task success and lower rework across agents, rather than merely nicer screenshots? What if candidate loses to native baseline?
- Are license assumptions correct for copied fonts/photos/icons/scripts and the Vercel wrapper vs underlying MIT content?

## 7. Source map (pinned public GitHub paths)

CVF Provenance observed commit `1c7125286cf185f00c7b9248aed506889c448aa9`:

- [CVF AGENTS.md](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/AGENTS.md)
- [ASSF Frontend UI SKILL](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-engineering-frontend-ui/SKILL.md)
- [ASSF Frontend UI Source](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-engineering-frontend-ui/skill.source.json)
- [ASSF Browser Verification SKILL](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-engineering-browser-runtime-verification/SKILL.md)
- [ASSF Skill Discovery SKILL](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-governance-skill-discovery-invocation/SKILL.md)
- [ASSF Package Contract](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/CVF_ASSF_PACKAGE_CONTRACT.md)
- [Skill Selection Guidance](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/CVF_SKILL_SELECTION_GUIDANCE_STANDARD.md)
- [Selection Profiles JSON](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/control_plane/source/skill-selection-profiles.json)
- [ASSF Production Runtime Standard](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/CVF_ASSF_PRODUCTION_PACKAGE_RUNTIME_STANDARD.md)
- [External Provider Skill Source-of-truth Standard](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/CVF_EXTERNAL_PROVIDER_SKILL_SOURCE_OF_TRUTH_STANDARD_2026-06-30.md)
- [Cross-workspace domain funnel](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/external_agent_review/CVF_CROSS_WORKSPACE_DOMAIN_FUNNEL_ABSORPTION_METHOD.md)
- [Cross-workspace evidence relay](https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/external_agent_review/CVF_CROSS_WORKSPACE_EVIDENCE_RELAY_METHOD.md)

External sources (R02 observed pins; Local recheck freshness and full package execution chain):

- [Anthropic frontend-design](https://github.com/anthropics/skills/blob/ca45fc496a3436251f191354091d557da31c15b5/skills/frontend-design/SKILL.md)
- [UI UX Pro Max SKILL](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/ccce51cba388476d4f403091ddb91636d5cd9fed/.claude/skills/ui-ux-pro-max/SKILL.md), [core.py](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/ccce51cba388476d4f403091ddb91636d5cd9fed/src/ui-ux-pro-max/scripts/core.py)
- [Taste Skill 2.5](https://github.com/Leonxlnx/taste-skill/blob/9b4bf937a1f69348126959c15d2f99a73e65699b/skills/taste-skill/SKILL.md), [Changelog](https://github.com/Leonxlnx/taste-skill/blob/9b4bf937a1f69348126959c15d2f99a73e65699b/CHANGELOG.md)
- [Vercel web-design-guidelines wrapper](https://github.com/vercel-labs/agent-skills/blob/1a2c79d4e6c4a2283dc2c614b6538cbe1ed5ca62/skills/web-design-guidelines/SKILL.md), [pinned guideline content](https://github.com/vercel-labs/web-interface-guidelines/blob/434b7f91364665f2f733b310ec54809bf8f37937/command.md)
- [Agent Skills specification](https://agentskills.io/specification)
- [Codex Build skills](https://learn.chatgpt.com/docs/build-skills)
- [Gemini CLI skills](https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/skills.md)

## 8. Final recommendation

**R03 advises:** Preserve CVF as root, LAW strictly optional downstream. Identify current CVF package owner and selection path first; selectively gather verified UI/UX resources into an independently maintainable content pack. **Do not assume new CVF skill owners are required.** Offer at most one tiny host-native entry adapter only after a genuine discovery/binding gap is shown. Test usefulness versus **native + existing CVF** on Python offline and web tasks, pin source revisions, and let Local Agent issue technical disposition and any governed follow-up work order.

**Do not claim:** new package adopted, any upstream skill safe/accepted, installer test completed, Claude/Codex/Gemini route verified, browser automation authorized, LAW integrated, private CVF gap confirmed, or production readiness.
