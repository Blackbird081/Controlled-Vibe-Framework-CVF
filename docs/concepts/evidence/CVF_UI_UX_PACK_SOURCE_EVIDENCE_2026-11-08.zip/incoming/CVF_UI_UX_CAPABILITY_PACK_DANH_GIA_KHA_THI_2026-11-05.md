# CVF UI/UX Capability Pack — Đánh giá khả thi và phạm vi đối soát

Ngày: 05/11/2026 (Asia/Ho_Chi_Minh)
Vai trò: reviewer tư vấn độc lập.
Trạng thái: đánh giá ý tưởng; không phải quyết định tiếp nhận, work order hoặc quyền thực thi.

## 1. Kết luận

**Khả thi về kỹ thuật và phù hợp định hướng CVF nếu được triển khai như nguồn chuyên môn UI/UX có chọn lọc, dùng qua owner và đường thực thi hiện hữu. Chưa đủ bằng chứng rằng một pack riêng hoặc adapter native mới là cần thiết, hay sẽ làm đầu ra tốt hơn.**

Tiếp tục xem xét ý tưởng; sửa phạm vi và thiết kế kiểm chứng trước khi giao implementation. Không cần thiết kế lại CVF, dựng UI framework, registry, dispatcher hoặc admission engine mới.

Ba vấn đề phải tách: nội dung chuyên môn có hữu ích không; agent có tìm/nạp đúng nội dung không; đường sử dụng có giữ đúng quyền và bằng chứng CVF không. Một câu trả lời tốt cho vấn đề này không tự trả lời hai vấn đề còn lại.

LAW nằm ngoài phạm vi. Các công việc, grant, closure và quyết định đang held/parked không được thay đổi bởi báo cáo này. CVF tiếp tục là hạ tầng governance, không trở thành framework giao diện.

## 2. Căn cứ và giới hạn đọc

Đầu vào chính là `CVF_UI_UX_CAPABILITY_PACK_AUDIT_R03_2026-11-05.md`, đặc biệt §2, §3, §4 và §5. Báo cáo này không giả định đã đọc R01/R02 hoặc chứng minh lại toàn bộ các repo trong shortlist.

Đối soát thêm qua GitHub read-only tại đúng các pin đã được cung cấp:

- CVF Provenance: `1c7125286cf185f00c7b9248aed506889c448aa9`.
- Nguồn frontend mà package CVF dẫn chiếu: `addyosmani/agent-skills@aba7c4e9695c363e65cb59effe926c7f1d1abe3d`.
- Anthropic: `anthropics/skills@ca45fc496a3436251f191354091d557da31c15b5`.
- UI UX Pro Max: `nextlevelbuilder/ui-ux-pro-max-skill@ccce51cba388476d4f403091ddb91636d5cd9fed`.
- Vercel guideline: `vercel-labs/web-interface-guidelines@434b7f91364665f2f733b310ec54809bf8f37937`.

Tài liệu live chính thức về Agent Skills, Claude Code, Codex và Gemini CLI được đọc ngày 05/11/2026 để kiểm các giả định native. Chúng không chứng minh phiên bản cài trên máy Local có cùng behavior.

Không đọc latest Local HEAD/dirty state; không xác minh CI hiện tại; không cài dependency, gọi provider, chạy utility upstream, mở browser/desktop app, thực hiện A/B hoặc nghiệm thu người dùng. Pin được đọc không được gọi là latest HEAD mới xác minh.

## 3. Điều đã kiểm tra trực tiếp

| Nguồn | Quan sát có căn cứ | Giới hạn |
|---|---|---|
| CVF `cvf-engineering-frontend-ui/SKILL.md` | Có `Status: ACTIVE`; hướng frontend, responsive, accessibility và runtime verification; quy định explicit receipt-backed package access; không tự cấp filesystem/browser/action authority | Không chứng minh host đang khám phá hoặc dùng được package; không kiểm lại chứng cứ production được tài liệu dẫn |
| CVF `cvf-governance-skill-discovery-invocation/SKILL.md`, đến dòng 155 | Metadata-first; dispatcher chọn Allowed Reads; worker không tự mở rộng danh sách; package body có ranh giới receipt-backed | Không phải kiểm toàn loader/resolver hay mọi đường native |
| Upstream Addy frontend skill, đến dòng 230 | Đã có component patterns, state management, design-system adherence, semantic color, typography, keyboard, ARIA và empty/error states | Là nội dung nguồn mà CVF dẫn; không chứng minh toàn bộ nội dung đang được truyền tới worker |
| Anthropic `frontend-design/SKILL.md` | Có design direction, typography, critique, content principles; yêu cầu brief thắng các stylistic defaults; khuyến nghị sentence case | Không phải chứng nhận chất lượng UI; các giả định về khách hàng trong prose không được coi là sự thật của task CVF |
| UI UX Pro Max `SKILL.md`, các phần Workflow/Stack trong vùng yêu cầu 1–240 (connector cắt phần cuối); `core.py`, đến dòng 210; `search.py`, đến dòng 230 | Có nguồn CSV theo domain, cấu hình stack, CLI search và chế độ persist; `search.py` import `core` và `design_system` trước xử lý arguments | Chưa audit toàn bộ dependency chain, không chạy và chưa xác nhận một invocation cụ thể là read-only |
| Vercel `command.md`, đến dòng 210 | Checklist web với accessibility/focus/forms, content handling, i18n; có quy tắc Title Case | Không phải toàn bộ chuẩn accessibility; không phải guideline cho mọi desktop stack |
| Agent Skills spec | Định dạng chuẩn chung yêu cầu YAML `name`/`description` | Tuân chuẩn file không chứng minh host path, selection, permission hoặc receipt |
| Claude Code docs | Frontmatter fields được mô tả là optional; description có thể lấy từ paragraph đầu; `allowed-tools` có thể pre-approve tool; body đã nạp tiếp tục nằm trong context | Không suy giống nhau cho mọi host hoặc bản cũ |
| Gemini CLI docs | Activation có consent; skill body được nạp và thư mục skill được thêm vào allowed file paths | Consent của host không tự là admission/receipt CVF |

## 4. Các điều chỉnh cần thiết đối với R03

### F01 — A/B/C không phải ba kiến trúc loại trừ nhau

Locator: R03 §3.

A trả lời **ai sở hữu**; B trả lời **nội dung được đóng gói/bảo trì ở đâu**; C trả lời **host truy cập thế nào**. Một bundle tài liệu tách riêng vẫn có thể thuộc owner frontend hiện hữu và không cần native entry mới.

Không chọn số lượng package/entry trước. Bắt đầu bằng nội dung cần cho một consumer; chọn cách lưu dễ bảo trì trong hợp đồng đang có. Chỉ tạo thêm wrapper khi có thiếu sót về discovery/access. Một logical entry có thể cần projection/config khác nhau theo host; điều đó không đồng nghĩa tạo nhiều CVF owners.

Không có nội dung mới không tự loại package: phân phối đúng lúc có thể là giá trị riêng. Ngược lại, có nội dung tốt không buộc phải tạo package.

### F02 — Thiếu YAML chưa đủ chứng minh cần adapter

Locator: R03 F03-04; official Agent Skills specification; Claude Code docs, Frontmatter reference.

R03 đúng khi tách ASSF lifecycle khỏi host-native discovery. Nhưng cách mô tả cả Claude/Codex/Gemini cùng bắt buộc frontmatter là quá tuyệt đối: tài liệu Claude hiện cho phép các field optional và suy description từ đoạn đầu.

Sửa tối thiểu: kiểm exact host/version, discovery directory, precedence, explicit/implicit invocation và resource paths. Thiếu chuẩn metadata chung là vấn đề portability cần xem xét, không phải bằng chứng độc lập rằng file không thể được một host đọc.

### F03 — Native entry phải bảo toàn đường đọc, không chỉ bảo toàn lời nhắc

Locator: R03 §4.4; CVF frontend SKILL, Progressive Disclosure / Claim Boundary; discovery SKILL, Worked Discovery Practice Examples.

Sample entry yêu cầu đọc approved index/reference nhưng chưa xác định rõ việc này đi qua loader/receipt nào. Nếu trỏ trực tiếp vào ASSF package body đang yêu cầu receipt-backed access, có thể tạo đường dùng khác contract. Đây là rủi ro thiết kế có điều kiện, chưa phải bypass đã xảy ra.

Cần phân biệt hai trường hợp hợp lệ để Local chọn:

- Đọc reference có scope/quyền đã cấp, không nhận đó là một lần ASSF invocation.
- Sử dụng ASSF package qua loader/executor/adapter và evidence path hiện hữu.

Metadata discovery không tự mở quyền đọc mọi body. Không nhúng nguyên package body vào wrapper rồi coi nó vẫn chỉ là metadata. Không dùng `verified`/`ACTIVE` trong wrapper làm nguồn trạng thái riêng.

Native metadata có thể ảnh hưởng quyền thực: Claude có `allowed-tools`, Gemini activation có thể mở đọc thư mục resource. Vì vậy bản đầu nên không pre-approve tool, không dynamic shell preprocessing, không trộn candidate/private evidence vào thư mục được host cho đọc. Phải kiểm native configuration thực thay vì chỉ có câu “không cấp quyền”.

### F04 — R03 lặp lại điều kiện không cần thiết giữa content và discovery

Locator: R03 §5, Treatment C “chỉ chạy khi B tốt mà agent thường xuyên không tìm ra nguồn”.

Phản ví dụ: nội dung hiện có đã đủ khi được đưa trực tiếp, nhưng agent thường không tìm/nạp được nó. Bổ sung nội dung không tăng chất lượng; cải thiện entry/discovery vẫn có ích.

Sửa tối thiểu: kiểm bridge khi có gap tìm/nạp hoặc binding đã được quan sát, độc lập với việc có cần nội dung mới hay không. So cùng nội dung trên các cách phân phối. Không bắt content uplift là điều kiện của distribution uplift.

### F05 — Cần tuyển chọn từng rule và bảo toàn quyết định thiết kế của sản phẩm

Locator: R03 §2 F03-07, §4.2; Anthropic More on writing in design; Vercel Content & Copy; Addy Design System Adherence; UI UX Pro Max Workflow.

Có xung đột thật: Anthropic khuyên sentence case, Vercel quy định Title Case cho headings/buttons. Các hướng dẫn typography, motion, marketing hero, density không thể cùng thành global requirements.

Giá trị tuyển chọn là làm rõ khi nào một rule áp dụng. Brief, design system đã được chấp nhận, ngôn ngữ và stack của sản phẩm phải điều khiển lựa chọn; không để xu hướng “trông khác AI” thay nhu cầu sử dụng.

Không tự tạo thêm `design-system/.../MASTER.md` từ utility làm source-of-truth cạnh tranh DESIGN.md/tokens hiện hữu. Đầu ra generator chỉ là đề xuất trước review; mode persist/force phải có phạm vi riêng.

Đọc upstream Addy cho thấy các nguyên tắc chung đã tồn tại trong source lineage. Lợi ích còn có thể là dữ liệu palette/font cụ thể, case tiếng Việt, workflow states, retrieval hoặc checklist tình huống; không nên giới thiệu mọi nguyên tắc cơ bản là novelty.

### F06 — Pilot được gọi “nhỏ nhất” nhưng đang quá rộng và lệch consumer

Locator: R03 §5, P1–P3 và H1–H8.

R03 chọn CVF làm consumer trực tiếp, nhưng pilot mở CustomTkinter Excel reconciler, NiceGUI/Streamlit dashboard và React/HTML, rồi kiểm ba hosts. Đây là kiểm khả năng tái dùng đa nền tảng, không phải điều kiện tối thiểu để chứng minh một cải thiện CVF UI.

Chọn một workflow CVF hiện hữu có nhu cầu cụ thể, một host và stack hiện hành; dùng dữ liệu synthetic/bản sao cô lập trong quyền. Python desktop và các host khác là kiểm portability về sau, khi có consumer và nhu cầu thật.

`STACK_CONFIG` của UI UX Pro Max ở pin đã đọc không có Tkinter/CustomTkinter/Streamlit/NiceGUI. Nguyên tắc UX chung có thể chuyển giao, nhưng không được ghi nhận implementation support cho các stack này từ đó. Python-local-web và native desktop phải có proof khác nhau.

### F07 — Đừng quy lợi ích của browser/tool mới cho content pack

Locator: R03 §5, Treatment D và Record.

Khi đo content, baseline và candidate cần có cùng quyền, model/effort, công cụ, test và feedback budget. Chỉ khác nội dung đang kiểm. Thêm browser vào riêng candidate sẽ đo cả công cụ lẫn nội dung.

Khi đo discovery, giữ nội dung tương đương và cho phép cơ chế tìm/nạp khác nhau; không đưa sẵn toàn bộ reference cho cả hai rồi gọi đó là discovery test. Dùng phiên sạch để tránh câu trả lời/thiết kế của lượt trước làm gợi ý cho lượt sau.

Không lấy screenshot đẹp hơn thay cho task success, correctness, keyboard behavior hoặc product acceptance. Khởi đầu nhỏ cho tín hiệu thực nghiệm, không claim cross-host generalization/statistical proof.

### F08 — Fallback và revocation cần thêm điều kiện

Locator: R03 §4.4 dòng “continue using existing native capabilities”; §5 H7.

Reference tùy chọn không sẵn sàng: có thể tiếp tục bằng native trong cùng quyền và ghi giới hạn. Reference/design system là acceptance bắt buộc hoặc approval không xác định: giữ phần phụ thuộc, không tự thay bằng style chung rồi báo đạt.

Không được hiểu xóa file hoặc thay index là xóa nội dung đã nạp khỏi phiên agent. Tài liệu Claude nói body đã gọi còn trong context. Khi thu hồi, kiểm cả phiên đã nạp và phiên mới; dùng stop/authority boundary sẵn có hoặc phiên mới thích hợp, không cần dựng cơ chế revocation riêng để làm pilot.

### Ghi chú phân loại

Các nhãn CRITICAL/HIGH ở F03-01..06 của R03 chủ yếu mô tả tầm quan trọng kiến trúc; không phải các lỗ hổng CVF nghiêm trọng đã xác nhận. Không tạo defect remediation ticket chỉ vì đã tìm thấy một existing owner.

## 5. Phương án đề xuất

Đích: người dùng nhận UI phù hợp công việc, dễ hiểu, dùng được và ít cần sửa lại — không phải thu thập nhiều skills.

Luồng đề xuất:

```text
Một công việc UI của CVF đã được chọn
  -> scope, brief, design system và acceptance hiện hữu
  -> owner/selection hiện hữu
  -> reference đã cho phép, đúng stack và tình huống
  -> agent sử dụng native coding/verification trong quyền
  -> artifact + kiểm chứng + operator acceptance
```

Một native entry nhỏ chỉ chen vào khâu tìm/nạp nếu đường hiện hữu thiếu. Utility chỉ được thêm khi cần tìm kiếm/tính toán mà đọc reference trực tiếp không đáp ứng tốt.

Trong lượt thử nội dung đầu: không installer, không registry mới, không auto-update, không host-global entry, không asset/font download, không change UI framework. Không sao chép cả upstream repo vào context hay coi README claims là proof.

Nếu nội dung mới không giúp nhưng discovery cải thiện, giữ cải thiện discovery. Nếu native + CVF hiện có đã đủ, dừng ở reference/no-change. Nếu cả nội dung và discovery có giá trị, bundle có phạm vi là lựa chọn hợp lý.

## 6. Phép kiểm nhỏ nhất đề xuất — chưa được thực hiện

### Chọn việc thật, không tạo sản phẩm phụ để chứng minh pack

Local chọn một màn hình/luồng CVF hiện hữu được phép đánh giá. Ví dụ chỉ để minh họa: trình bày trạng thái/kết quả một công việc rõ hơn cho người dùng tiếng Việt, không đổi semantics approval, grant hoặc execution. Không coi ví dụ này là chỉ định resume HTML M6, JEV-S1 hoặc lane đang held.

Một việc cải thiện và một tình huống review-only/backend-only đủ để bắt đầu thu bằng chứng. Chỉ mở thêm task/run khi kết quả còn mơ hồ và ngân sách cho phép. Không bắt ba stacks và ba hosts làm điều kiện đầu tiên.

### So đúng câu hỏi

- **Nội dung:** A = native + CVF hiện hữu; B = A + một phần reference được chọn. Giữ cùng source base, task, dữ liệu, model/effort, quyền, công cụ verification và giới hạn sửa.
- **Discovery, nếu thiếu:** cùng nội dung được phép, so cơ chế hiện có với entry/projection được review riêng. Không yêu cầu B đã có content uplift nếu đang dùng nội dung hiện có.
- **Utility, nếu cần:** kiểm exact invocation cùng modules/data được nó import; không gọi `--help` trước source-chain review. Search-only và persist là hai phạm vi khác nhau.

### Tiêu chí đọc kết quả

| Nhóm | Bằng chứng cần xem |
|---|---|
| Đúng nghiệp vụ | Không thay meaning của trạng thái, số liệu, nút và điều kiện quyền; giữ regression liên quan |
| Dùng được | Người dùng hoàn thành hành động mục tiêu; nhãn tiếng Việt dài, empty/loading/error, focus/keyboard được kiểm trong platform thực |
| Phù hợp thiết kế | Tôn trọng brief/design tokens; không biến dashboard thành landing page; không đổi style khi chỉ yêu cầu review |
| Ranh giới | Không download/install/network/ghi ngoài scope; nguồn được đọc đúng identity và quyền; missing required source không thành PASS |
| Tổng công | Số lỗi, vòng sửa, thời gian can thiệp, usage/token khi đo được; thiếu số liệu ghi UNKNOWN |
| Giá trị Human | Operator đánh giá theo rubric thống nhất trước; không tự tạo điểm Human, không coi agent persona là người dùng độc lập |

Browser/GUI chưa chạy thì kết luận ở mức source/static hoặc screenshot được review, không gọi là runtime interaction proof. “Offline” phải ghi rõ là utility offline, artifact không dùng mạng, hay agent inference offline; ba điều này khác nhau.

## 7. Yêu cầu đối soát Local gọn

Local chỉ cần trả lại một kết luận có nguồn cho consumer đã chọn:

1. Đường sử dụng UI guidance hiện tại: source/owner/loader/entry thực; nội dung nào worker thực sự nhận.
2. Gap cụ thể: thiếu kiến thức, thiếu dữ liệu thiết kế, thiếu discovery hay thiếu verification; không suy từ tên package.
3. Chọn reference/no-change, enrich existing, bundle hay host projection; nêu đúng source paths và phần còn giữ lại.
4. Mức bằng chứng và quyền còn thiếu cho phép kiểm nhỏ; tách admission nội dung, install, execute, provider exposure và publication.

Không yêu cầu full-repo audit, sửa guard/schema để ép candidate vào, viết lại P01–P10 hoặc tạo chương trình độc lập với NCR. Thiếu quyền chỉ giữ phần phụ thuộc; các công việc độc lập đã được phép vẫn tiếp tục.

## 8. Source locators để kiểm tra trực tiếp

### CVF và nguồn đang được owner dẫn chiếu

- https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-engineering-frontend-ui/SKILL.md
  - Purpose; Invocation Boundary; Progressive Disclosure; Claim Boundary; Public Export Disposition.
- https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/blob/1c7125286cf185f00c7b9248aed506889c448aa9/docs/reference/agent_system_skills/packages/cvf-governance-skill-discovery-invocation/SKILL.md
  - Đã đọc đến dòng 155; Worked Discovery Practice Examples; Progressive Disclosure.
- https://github.com/addyosmani/agent-skills/blob/aba7c4e9695c363e65cb59effe926c7f1d1abe3d/skills/frontend-ui-engineering/SKILL.md
  - Đã đọc dòng 1–230; Component Architecture; Design System Adherence; Accessibility.

### Candidates được kiểm tra chọn lọc

- https://github.com/anthropics/skills/blob/ca45fc496a3436251f191354091d557da31c15b5/skills/frontend-design/SKILL.md
  - Process; More on writing in design; brief precedence.
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/ccce51cba388476d4f403091ddb91636d5cd9fed/.claude/skills/ui-ux-pro-max/SKILL.md
  - Đọc chọn lọc Workflow, Persist Design System, Stack Guidelines trong vùng yêu cầu 1–240; output connector bị cắt ở phần cuối, không tuyên bố đọc đầy đủ toàn vùng.
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/ccce51cba388476d4f403091ddb91636d5cd9fed/src/ui-ux-pro-max/scripts/core.py
  - Đã đọc dòng 1–210; DATA_DIR; CSV_CONFIG; STACK_CONFIG.
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/blob/ccce51cba388476d4f403091ddb91636d5cd9fed/src/ui-ux-pro-max/scripts/search.py
  - Đã đọc đến dòng 230; imports; argparse; design-system / stack / domain branches; persist/force flags.
- https://github.com/vercel-labs/web-interface-guidelines/blob/434b7f91364665f2f733b310ec54809bf8f37937/command.md
  - Đã đọc đến dòng 210; Forms; Content & Copy; Locale & i18n.

### Host/spec docs đọc ngày 05/11/2026

- https://agentskills.io/specification — SKILL.md format, progressive disclosure.
- https://learn.chatgpt.com/docs/build-skills — explicit/implicit invocation, discovery metadata.
- https://developers.openai.com/plugins/concepts/skills — workflow resources, distinction from tools/actions.
- https://code.claude.com/docs/en/skills — Frontmatter reference; Pre-approve tools; Skill content lifecycle.
- https://geminicli.com/docs/cli/skills/ — How it works; consent and directory resource access.

Chưa audit trực tiếp Taste, Fluent Blue, Vercel React/composition, Anthropic webapp-testing, licenses/assets hoặc toàn bộ parser/utility của UI UX Pro Max trong lượt này. Giữ các mục đó là shortlist trong R03, không biến thành nguồn đã được reviewer này chấp nhận.

## 9. Handoff

- **Nguồn:** R03 đính kèm; source/spec được nêu ở §8.
- **Kết luận:** khả thi có phạm vi; cần sửa điều kiện native, phân loại nội dung và phép kiểm; chưa chứng minh lợi ích.
- **Thay đổi đề xuất:** tách owner/content/access; không khóa content uplift trước discovery; thu pilot về một CVF consumer; bảo toàn receipt/permission; tuyển chọn từng rule.
- **Chưa làm:** local freshness, runtime/GUI/A-B, source-chain execution test, license completeness, installation/adoption, operator acceptance.
- **Quyền:** review/read-only và soạn artifact; không cấp quyền triển khai hoặc resume.
- **Artifact:** chính file này; không thay Project CURRENT hoặc GitHub.
- **Bước tiếp:** Local đối soát một consumer và đường đọc hiện hữu, rồi chọn phép kiểm nhỏ đúng gap trong authority đang có. Không cần thêm vòng ACK tư vấn.
